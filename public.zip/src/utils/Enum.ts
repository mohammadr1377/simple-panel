export  enum TypeToastEnum{
    info="info",
    success="success",
    warning="warn",
    error="error",

}