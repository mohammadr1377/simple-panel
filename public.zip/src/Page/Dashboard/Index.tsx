export default function Dashboard() {
    return(
        <>
            <p>داشبورد</p>
        </>
    )
}