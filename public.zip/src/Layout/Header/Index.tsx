import removeItemLocalStorage from "../../utils/removeItemLocalStorage";

export default function IndexHeader() {
    function handelerLogOut() {
        removeItemLocalStorage("isLogin")
       
    }
    return(
        <>
        <header className="h-10 mt-2 rounded-lg  w-full justify-between bg-blue-50 shadow-2xl flex items-center p-2">
            <p>نام کاربری</p>
            <button onClick={handelerLogOut}> خروج</button>
        </header>
        </>
    )
}