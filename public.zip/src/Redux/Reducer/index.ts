const defaultState = {
  PersonalData:{
    name: '',
    family:''
  },
  isLogin:false
   
    
  };
  
  export default function Auth(state=defaultState, action:any = {}) {
    switch(action.type) {
      case 'LOGIN':
        return {
          ...state,
          PersonalData:{
            name:action.name,
            family:action.family,
          },
          isLogin:true,
          
        };
      case 'LOGOUT':
        return {
          ...state,
          PersonalData:{
            name:"",
            family:"",
          },
          isLogin:false,
          
        };
      default:
        return state;
    }
  }